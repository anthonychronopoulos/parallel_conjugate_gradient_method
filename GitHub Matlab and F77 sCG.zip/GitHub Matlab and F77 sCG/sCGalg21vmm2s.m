function [x]= sCGalg21vmm2s(A,b,s,x,K,tol)
%version with O(2s) inner products
n=size(A,1);
bpr=zeros(n,1); 
z=zeros(n,1);
ztmp=zeros(n,1);
r= zeros(n,1);
rtmp= zeros(n,1);
ro=zeros(K,1);                         
   m=zeros(s,1);
   M=zeros(s,s);
   Mold=zeros(s,s);
   C=zeros(s,s);
   b1=zeros(s,s);
 a=zeros(s,1);  
R=zeros(n,s);
P=zeros(n,s);
AR=zeros(n,s);
AP=zeros(n,s);
ARold=zeros(n,s);
Pold=zeros(n,s);
Rold=zeros(n,s);
APold=zeros(n,s);
vm= zeros(2*s,1);
PW=zeros(s,s);
vmm= zeros(2*s,1);



%% Initial residual 
r=b-A*x;   

R(:,1)= r; 
% s matrix*vector 
for k=2:s
    R(:,k)=A*R(:,k-1);    
   end
for k=2:s
     AR(:,k-1)= R(:,k);
end
   AR(:,s)= A*R(:,s);
% All inner products done together at the first iteration of sCG
  rnorm=norm(r);
% form 2*s moments to be used in m and M
for j=1:s-1
  vm(2*j-1)=R(:,j)'*R(:,j);
  vm(2*j)=R(:,j)'*R(:,j+1);
end
  vm(2*s-1)=R(:,s)'*R(:,s);
  vm(2*s)=R(:,s)'*AR(:,s);

%scalar work
for j=1:s
  m(j)=vm(j);
end

  for j=1:s
    for k=1:s
    PW(j,k)=vm(j+k);
end
end
M=PW;

   a = linsolve(M,m);

% Store P, A*P
  P=R;
  AP=AR;

% MAIN ITERATION START

for i=1: floor(K/s)+1

% loop termination condition
ro(i)= rnorm;
if    rnorm<tol                              
       break                                                          
end   
    
%%  new solution and residual vectors
  
x=x+P*a;
r=b-A*x;

   Rold=R;
   ARold= AR;
R(:,1)= r; 
% s matrix*vector products
for k=2:s
    R(:,k)=A*R(:,k-1);    
   end
for k=2:s
     AR(:,k-1)= R(:,k);
end
   AR(:,s)= A*R(:,s);



% All inner products done together at each iteration of sCG

  rnorm=norm(r);
% form 2*s moments to be used in m and M
for j=1:s-1
  vm(2*j-1)=R(:,j)'*R(:,j);
  vm(2*j)=R(:,j)'*R(:,j+1);
end
  vm(2*s-1)=R(:,s)'*R(:,s);
  vm(2*s)=R(:,s)'*AR(:,s);



%Scalar work start

vmm= zeros(2*s,1);
for i1=1:s 
  vmm(s-1+i1)=vm(i1);
    for j=1:i1-1 
      vmm(s-1+i1)= vmm(s-1+i1)+ vmm(s-1+j)*a(s-i1+j);
    end
     vmm(s-1+i1)= -vmm(s-1+i1)/a(s);
end

for j=1:s-1
  vmm(j)=0;
end
for i1=1:s
  for j=1:s
       C(j,i1)=vmm(i1+j-1);
end
end

for j=1:s
  m(j)=vm(j);
end

  for j=1:s
    for k=1:s
    PW(j,k)=vm(j+k);
end
end

Mold=M;
M=PW;

b1 = -linsolve(Mold,C);
M=M+b1'*C;
a = linsolve(M,m);

%  scalar  work end

  Pold=P;
  APold= AP;

 P=R+Pold*b1;
 AP=AR + APold*b1;



    
% MAIN ITERATION END
end 


toc
disp(['iter_sCGalg21vmm2s=',num2str(i),'tol',num2str(tol), 'rnrm=', num2str(rnorm), '  s=',num2str(s) ])
%disp(i)
h=1:length(ro);
ro=log10(ro);
plot(h,ro,'--')
legend('sCG(I)','sCG(II)') 
hold on
%end function
end 
