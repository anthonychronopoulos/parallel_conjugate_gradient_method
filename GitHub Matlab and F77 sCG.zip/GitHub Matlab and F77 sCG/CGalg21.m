function [x]= CGalg21(A,b,x,K,tol)              
% function with output x , ro and input A,b,x initial vector
warning('off');                                                                                                                   % clear screen
clear  r;                                                              
r=b-A*x;                                                    
  p=r;                                                               
rsold=r'*r;    
rnorm=sqrt(rsold);
ro=zeros(K,1);                         
ro(1)=rnorm;                                                                                                               
for i=1:K                                      
   Ap=A*p;                                                      
   alpha=rsold/(p'*Ap);                                                                  
   x=x+alpha*p;                                               
   r=r-alpha*Ap;                                              
   rsnew=r'*r; 
   rnorm=sqrt(rsnew);                                        
         ro(i+1)=rnorm;                                              
   if   ( rnorm<tol )                             
       break                                                          
   end                                                                   
beta=rsnew/rsold;
   p=r+beta*p;                                
rsold = rsnew;                                      
end  

disp(['iter_CGalg21=',num2str(i),'rnrm=', num2str(rnorm), 'tol=',num2str(tol)])
toc
h=1:length(ro);                                            
ro=log10(ro);                                                       
plot(h,ro,'g-.')                                                           
 legend('sCGalg2','sCGalg21','CG21')  
hold on                                                               
end                                                                       
