function [x]= PrCGalg21(A,b,x,K,tol)   
% function with output x , ro and input A,b,x initial vector
warning('off');                                                                                                                   % clear screen
clear  r;     
n=size(A,1);
bpr=zeros(n,1); 
z=zeros(n,1);
ztmp=zeros(n,1);
r= zeros(n,1);
ro=zeros(K,1); 
L=ichol(A);

%% Initial residual %r=b-A*x;   
%%  compute prec rhs (bpr), ONLY ONCE:                    
bpr=L\b; 
%% ICF Initial residual , x is initial soln vect
z=L'\x; 
ztmp=A*z;  
z=L\ztmp;
%% prec Initial residual 
r=bpr-z;  

p=r;                                                               
rsold=r'*r;    
ro=zeros(K,1);                         
ro(1)=norm(r);  
% MAIN LOOP                                                                                                             
for i=1:K 
% prec   Ap=A*p;                                                      
    z=L'\p; 
    ztmp=A*z;  
    z=L\ztmp; 
   Ap=z;                                                                                                                                      
   alpha=rsold/(p'*Ap);                                                                  
   x=x+alpha*p;                                               
   r=r-alpha*Ap; 
   rnorm=norm(r);                                        
         ro(i+1)=rnorm;                                              
   if   ( rnorm<tol)                             
       break                                                          
   end  
   rsnew=r'*r; 
                                                               
beta=rsnew/rsold;
   p=r+beta*p;                                
rsold = rsnew;                                      
end 

  z=L'\x ;
x=z;
toc
disp(['iter_PrCGalg21=',num2str(i),'rnrm=', num2str(rnorm), 'tol=',num2str(tol)])

h=1:length(ro);                                            
ro=log10(ro);                                                       
plot(h,ro,'g-.')                                                           
 legend('sCRalg21','sCGalg21',' CholCGalg21')  
hold on                                                               
end                                                                       
